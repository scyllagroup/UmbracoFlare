﻿angular.module("umbraco").controller("Cloudflare.Support.Controller",
	function ($scope, $timeout, cloudflareResource, notificationsService, navigationService) {


	});
