﻿angular.module("umbraco").controller("Cloudflare.License.Controller",
	function ($scope, $timeout, cloudflareResource, notificationsService, navigationService) {


	});