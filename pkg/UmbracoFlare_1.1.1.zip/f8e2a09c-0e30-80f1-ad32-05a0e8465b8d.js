﻿angular.module('umbraco').controller('demo.toggler', function ($scope, appState, eventsService) {
    //Create an Angular JS controller and inject Umbraco services appState & eventsService

    

});